﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CleanUI
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void MainWindow_OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();

        }

        private void Image_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void TextBox_MouseEnter(object sender, MouseEventArgs e)
        {
            if (loginuser.Text == "login")
            {
                loginuser.Text = "";
            }
        }

        private void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            if (loginuser.Text == "")
            {
                loginuser.Text = "login";
            }
        }

        private void txtPass_MouseEnter(object sender, MouseEventArgs e)
        {
            if (txtPass.Password == "Password")
            {
                txtPass.Password = "";
            }
        }

        private void txtPass_MouseLeave(object sender, MouseEventArgs e)
        {
            if (txtPass.Password == "")
            {
                txtPass.Password = "Password";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

